<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="tilemap_packed" tilewidth="8" tileheight="8" tilecount="150" columns="15">
 <image source="../Default/Tilemap/tilemap_packed.png" width="120" height="80"/>
</tileset>
